//
//  InmateTableViewCell.swift
//  UtahNasa
//
//  Created by Lon Chandler Madsen on 8/4/21.
//

import UIKit

class InmateTableViewCell: UITableViewCell {

    //MARK: - Outlets
    
    @IBOutlet weak var mugshotImageView: UIImageView!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    var inmate: Inmate? {
        didSet {
            updateViews()
        }
    }
    
    func updateViews() {
        guard let inmate = inmate else { return }
        nameLabel.text = inmate.name
        
        InmateController.fetchThumbnail(thumbnailURL: inmate.mugshot) { result in
            DispatchQueue.main.async {
                
                switch result {
                
                case .success(let mugshot):
                    self.mugshotImageView.image = mugshot
                    self.mugshotImageView.contentMode = .scaleToFill
                    self.mugshotImageView.layer.cornerRadius = 15
                case .failure(_):
                    self.mugshotImageView.image = UIImage(named: "NoImage")
                    self.mugshotImageView.contentMode = .scaleAspectFit
                }
                
            }
        }
        
    }

}
