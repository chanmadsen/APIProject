//
//  InmateTableViewController.swift
//  UtahNasa
//
//  Created by Lon Chandler Madsen on 8/4/21.
//

import UIKit

class InmateTableViewController: UITableViewController {

    var inmate: [Inmate] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        InmateController.fetchInmate { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let inmates):
                    self.inmate = inmates
                    self.tableView.reloadData()
                case .failure(let error):
                    print(error)
                }
            }
        }
    
    }

    // MARK: - Table view data source


    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return inmate.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "inmateCell", for: indexPath) as? InmateTableViewCell else { return UITableViewCell() }

        let inmate = self.inmate[indexPath.row]
        cell.inmate = inmate
        return cell
    }


  
    // MARK: - Navigation

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "toDetailVC" {
            guard let indexPath = tableView.indexPathForSelectedRow,
                  let destination = segue.destination as? InmateDetailViewController else { return }
            
            destination.inmate = self.inmate[indexPath.row]
        }
        
    }
    

}//end of class
