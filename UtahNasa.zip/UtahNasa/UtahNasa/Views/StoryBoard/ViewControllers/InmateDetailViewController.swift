//
//  InmateDetailViewController.swift
//  UtahNasa
//
//  Created by Lon Chandler Madsen on 8/4/21.
//

import UIKit

class InmateDetailViewController: UIViewController {

    //MARK: - Outlets
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var mugshotImageView: UIImageView!
    @IBOutlet weak var dateBooked: UILabel!
    @IBOutlet weak var chargesLabel: UILabel!
    
    
    
    var inmate: Inmate?
    
    override func viewDidLoad() {
        super.viewDidLoad()

       updateViews()
    }
    

    
    func updateViews() {
        guard let inmate = inmate else { return }
        nameLabel.text = inmate.name
        dateBooked.text = inmate.dateBooked
        chargesLabel.text = inmate.charges.joined(separator: ", ")
        
        InmateController.fetchThumbnail(thumbnailURL: inmate.mugshot) { result in
            DispatchQueue.main.async {
                
                switch result {
                
                case .success(let mugshot):
                    self.mugshotImageView.image = mugshot
                    self.mugshotImageView.contentMode = .scaleToFill
                    self.mugshotImageView.layer.cornerRadius = 15
                case .failure(_):
                    self.mugshotImageView.image = UIImage(named: "NoImage")
                    self.mugshotImageView.contentMode = .scaleAspectFit
                }
                
            }
        }
    }


}
