//
//  InmateError.swift
//  UtahNasa
//
//  Created by Lon Chandler Madsen on 8/4/21.
//

import Foundation

enum InmateError: LocalizedError {
    
    case invalidURL
    case thrownError(Error)
    case noData
    case unableToDecode
    
    var errorDescription:String {
        switch self {
        case .invalidURL:
            return "The server failed to reach the necessary URL."
        case .thrownError(let error):
            return "There was an error with our network call -- \(error)."
        case .noData:
            return "There was no data>"
        case .unableToDecode:
            return "Unable to recode the data, potentionally an issue with model object(s), or with the process of decoding."
        }
    }
}
