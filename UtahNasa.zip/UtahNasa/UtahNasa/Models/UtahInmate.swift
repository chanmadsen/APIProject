//
//  UtahNasa.swift
//  UtahNasa
//
//  Created by Lon Chandler Madsen on 8/4/21.
//

import Foundation

struct TopLevelObject: Codable {
    
    let records: [Inmate]
    
}

struct Inmate: Codable {
    let dateBooked: String
    let name: String
    let mugshot: String
    let charges: [String]
    
    enum CodingKeys: String, CodingKey {
        case dateBooked = "book_date_formatted"
        case name
        case mugshot
        case charges
    }
}


