//
//  File.swift
//  UtahNasa
//
//  Created by Lon Chandler Madsen on 8/4/21.
//

import Foundation
import UIKit
class InmateController {
    
    static let cache = NSCache<NSString, UIImage>()
    
    static func fetchInmate(completion: @escaping (Result<[Inmate], InmateError>) -> Void) {
        
        let baseURL = URL(string: "https://www.jailbase.com/api/1/recent/?source_id=ut-utah")
        guard let finalURL = baseURL else { return completion(.failure(.invalidURL)) }
        print(finalURL)
        
        URLSession.shared.dataTask(with: finalURL) { data, response, error in
            
            if let error = error {
                return completion(.failure(.thrownError(error)))
            }
            
            if let response = response as? HTTPURLResponse {
                if response.statusCode != 200 {
                    print("Response Code: \(response.statusCode)")
                }
                
                
                guard let data = data else { return completion(.failure(.noData)) }
                
                do {
                    let topLevelObject = try JSONDecoder().decode(TopLevelObject.self, from: data)
                    let inmates = topLevelObject.records
                    
                    var arrayOfInmates: [Inmate] = []
                    for record in inmates {
                        arrayOfInmates.append(record)
                    }
                    completion(.success(arrayOfInmates))
                }catch{
                    return completion(.failure(.unableToDecode))
                }
            }
        }.resume()
        
    }//end of fetch
    
    static func fetchThumbnail(thumbnailURL: String, completion: @escaping (Result<UIImage, InmateError>) -> Void) {
        
        let cacheKey = NSString(string: thumbnailURL)
        if let image = cache.object(forKey: cacheKey) {
            return completion(.success(image))
        }
        
        guard let finalURL = URL(string: thumbnailURL) else { return completion(.failure(.invalidURL)) }
        print(finalURL)
        
        URLSession.shared.dataTask(with: finalURL) { data, _, error in
            if let error = error {
                return completion(.failure(.thrownError(error)))
            }
            guard let data = data else { return completion(.failure(.noData)) }
            
            guard let thumbnail = UIImage(data: data) else { return completion(.failure(.unableToDecode)) }
            self.cache.setObject(thumbnail, forKey: NSString(string: thumbnailURL))
            completion(.success(thumbnail))
            
        }.resume()
        
    }//End of function
    
}//end of class
